import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@SuppressWarnings("serial")
@WebServlet("/your-servlet-url")
public class DatabaseServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // JDBC code to create, use, and drop a database
        try (Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce",
                "root", "Anu@1234567")) {
            // Perform database operations here
            System.out.println("Connected to the database from servlet!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}