import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    public static void main(String[] args) {
        // JDBC URL, username, and password
        String url = "jdbc:mysql://localhost:3306/ecommerce";
        String user = "root";
        String password = "Anu@#1234567";

        // Establish the connection
        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            // Perform database operations here
            System.out.println("Connected to the database!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

